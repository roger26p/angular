import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

//rutas
import { APP_ROUTING } from './app.routes'

//components
import { AppComponent } from './app.component';
import { HeaderComponent }from './header.component';
import {BodyComponent }from './body/body.component';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './seccion4/navbar/navbar.component';
import { HomeComponent } from './seccion4/home/home.component';
import { SobreComponent } from './seccion4/sobre/sobre.component';
import { HeroesComponent } from './seccion4/heroes/heroes.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    BodyComponent,
    FooterComponent,
    NavbarComponent,
    HomeComponent,
    SobreComponent,
    HeroesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    APP_ROUTING
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
